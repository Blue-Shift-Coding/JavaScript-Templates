go(function() {
	// Write your graphics and animation code here

});
